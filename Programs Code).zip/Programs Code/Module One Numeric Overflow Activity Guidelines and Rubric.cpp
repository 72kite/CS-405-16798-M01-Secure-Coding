// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// CHANGES SUMMARY
// ---------------
// Problem:  add_numbers() and subtract_numbers() silently wrapped around on overflow/underflow,
//           producing corrupted results with no indication that anything went wrong.
//
// Solution: Changed both functions to return std::pair<bool, T> (C++11, no extra headers needed).
//           - pair::first  = true  -> operation succeeded; pair::second holds the correct result.
//           - pair::first  = false -> overflow/underflow was detected; operation was aborted.
//
//           Detection strategy differs by type family:
//             * Integer types  : bounds are checked BEFORE each operation using
//                                std::numeric_limits<T>::max() / min() so undefined behaviour
//                                is never triggered.
//             * Floating-point : IEEE 754 produces +-infinity instead of wrapping; std::isinf()
//                                is checked AFTER each operation.
//
//           Signed-vs-unsigned safety:
//             Comparing an unsigned T against zero with < triggers a compiler warning
//             ("comparison always false") and is logically wrong. Two tiny helper function
//             templates -- is_negative<T>() -- are overloaded on std::is_signed so the
//             right version is selected at compile time with no warnings and no C++17 needed.
//
//           test_overflow() and test_underflow() inspect pair::first and either print the
//           numeric result (pair::second) or a human-readable failure message.
//

#include <iostream>         // std::cout, std::endl
#include <limits>           // std::numeric_limits
#include <utility>          // std::pair, std::make_pair
#include <type_traits>      // std::is_signed, std::true_type, std::false_type
#include <cmath>            // std::isinf

// ---------------------------------------------------------------------------
// Helper: is_negative<T>(value)
//   Returns true only when the value is less than zero.
//   The signed overload does the real comparison; the unsigned overload always
//   returns false so the compiler never sees "unsigned < 0" (which warns).
// ---------------------------------------------------------------------------
template <typename T>
bool is_negative(T val, std::true_type  /*is_signed*/) { return val < T(0); }

template <typename T>
bool is_negative(T /*val*/, std::false_type /*is_unsigned*/) { return false; }

template <typename T>
bool is_negative(T val)
{
    return is_negative(val, std::is_signed<T>());
}

// ---------------------------------------------------------------------------
/// <summary>
/// Template function to compute: start + (increment * steps)
///
/// CHANGE: Return type changed from T to std::pair<bool, T>.
///   pair.first  == true   -> result is valid; pair.second holds the value.
///   pair.first  == false  -> overflow/underflow detected; operation aborted.
///
///   Integer detection  : pre-operation bounds check using numeric_limits.
///   Float   detection  : post-operation std::isinf() check.
/// </summary>
/// <typeparam name="T">Any numeric type supporting += and comparison</typeparam>
/// <param name="start">Starting value</param>
/// <param name="increment">Amount added per step</param>
/// <param name="steps">Number of iterations</param>
/// <returns>pair(true, result) on success, or pair(false, T{}) on overflow</returns>
// ---------------------------------------------------------------------------
template <typename T>
std::pair<bool, T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // ---- Integer path: check bounds BEFORE the addition ----
        if (std::numeric_limits<T>::is_integer)
        {
            // Positive increment: would we exceed MAX?
            if (!is_negative(increment) && result > std::numeric_limits<T>::max() - increment)
            {
                return std::make_pair(false, T());   // overflow: abort
            }

            // Negative increment (signed only, helper guards unsigned): would we go below MIN?
            if (is_negative(increment) && result < std::numeric_limits<T>::min() - increment)
            {
                return std::make_pair(false, T());   // underflow: abort
            }
        }

        result += increment;

        // ---- Floating-point path: check AFTER the addition ----
        // IEEE 754 overflow produces infinity, not a wraparound.
        if (!std::numeric_limits<T>::is_integer)
        {
            if (std::isinf(result))
            {
                return std::make_pair(false, T());   // overflowed to infinity: abort
            }
        }
    }

    return std::make_pair(true, result);   // success
}

// ---------------------------------------------------------------------------
/// <summary>
/// Template function to compute: start - (decrement * steps)
///
/// CHANGE: Return type changed from T to std::pair<bool, T>.
///   pair.first  == true   -> result is valid; pair.second holds the value.
///   pair.first  == false  -> underflow/overflow detected; operation aborted.
///
///   Integer detection  : pre-operation bounds check using numeric_limits.
///   Float   detection  : post-operation std::isinf() check.
/// </summary>
/// <typeparam name="T">Any numeric type supporting -= and comparison</typeparam>
/// <param name="start">Starting value</param>
/// <param name="decrement">Amount subtracted per step</param>
/// <param name="steps">Number of iterations</param>
/// <returns>pair(true, result) on success, or pair(false, T{}) on underflow</returns>
// ---------------------------------------------------------------------------
template <typename T>
std::pair<bool, T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // ---- Integer path: check bounds BEFORE the subtraction ----
        if (std::numeric_limits<T>::is_integer)
        {
            // Positive decrement: would we go below MIN?
            if (!is_negative(decrement) && result < std::numeric_limits<T>::min() + decrement)
            {
                return std::make_pair(false, T());   // underflow: abort
            }

            // Negative decrement (signed only, helper guards unsigned): would we exceed MAX?
            if (is_negative(decrement) && result > std::numeric_limits<T>::max() + decrement)
            {
                return std::make_pair(false, T());   // overflow: abort
            }
        }

        result -= decrement;

        // ---- Floating-point path: check AFTER the subtraction ----
        if (!std::numeric_limits<T>::is_integer)
        {
            if (std::isinf(result))
            {
                return std::make_pair(false, T());   // overflowed to infinity: abort
            }
        }
    }

    return std::make_pair(true, result);   // success
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // CHANGE: add_numbers now returns std::pair<bool,T>.
    //   pair.first  == true  -> print the numeric result (pair.second).
    //   pair.first  == false -> print an overflow message; no corrupted value is used.
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    std::pair<bool, T> result = add_numbers<T>(start, increment, steps);
    if (result.first)
    {
        std::cout << +result.second << std::endl;
    }
    else
    {
        std::cout << "Overflow detected! Operation aborted." << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);
    if (result.first)
    {
        std::cout << +result.second << std::endl;
    }
    else
    {
        std::cout << "Overflow detected! Operation aborted." << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // CHANGE: subtract_numbers now returns std::pair<bool,T>.
    //   pair.first  == true  -> print the numeric result (pair.second).
    //   pair.first  == false -> print an underflow message; no corrupted value is used.
    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    std::pair<bool, T> result = subtract_numbers<T>(start, decrement, steps);
    if (result.first)
    {
        std::cout << +result.second << std::endl;
    }
    else
    {
        std::cout << "Underflow detected! Operation aborted." << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    if (result.first)
    {
        std::cout << +result.second << std::endl;
    }
    else
    {
        std::cout << "Underflow detected! Operation aborted." << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative types see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative types see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu